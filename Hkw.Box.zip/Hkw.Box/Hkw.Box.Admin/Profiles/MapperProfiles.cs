﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hkw.Box.Admin.Profiles
{
    public class MapperProfiles: Profile
    {
        public MapperProfiles()
        {

            #region Manager       
            //CreateMap<ChangeAccount, Account>();
            #endregion



        }
    }
}
