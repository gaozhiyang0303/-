﻿using Hkw.Entity.ResultModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace Hkw.Entity.ResultModel
{
    public class BooleanResult:BaseResult
    {
        public Boolean Data { get; set; }
    }
}
