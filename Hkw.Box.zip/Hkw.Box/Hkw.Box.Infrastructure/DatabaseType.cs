﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hkw.Box.Infrastructure
{
    /// <summary>
    /// 数据库类型
    /// </summary>
    public enum DatabaseType
    {
        SqlServer,
        MySQL,
        PostgreSQL,
        Oracle,
        SQLite,
    }
}
