﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Models;
using Models.DataTable;

namespace WebFront.Controllers
{
    public class UserController : Controller
    {
        private readonly DBCoreFirst _context;

        public UserController(DBCoreFirst context)
        {
            _context = context;
           
        }

        // GET: User
        public async Task<IActionResult> Index()
        {
            var company = new DT_Company()
            {

                Name = "大风厂",
                Address = "天津市河西区",
                TelPhone = "18222937244",
                CreatTime = DateTime.Now

            };
            _context.Add(company);
            await _context.SaveChangesAsync();
            return View(await _context.DT_User.ToListAsync());
        }

        // GET: User/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dT_User = await _context.DT_User
                .SingleOrDefaultAsync(m => m.ID == id);
            if (dT_User == null)
            {
                return NotFound();
            }

            return View(dT_User);
        }

        // GET: User/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: User/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,UserName")] DT_User dT_User)
        {
            if (ModelState.IsValid)
            {
                _context.Add(dT_User);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(dT_User);
        }

        // GET: User/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dT_User = await _context.DT_User.SingleOrDefaultAsync(m => m.ID == id);
            if (dT_User == null)
            {
                return NotFound();
            }
            return View(dT_User);
        }

        // POST: User/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,UserName")] DT_User dT_User)
        {
            if (id != dT_User.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(dT_User);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DT_UserExists(dT_User.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(dT_User);
        }

        // GET: User/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dT_User = await _context.DT_User
                .SingleOrDefaultAsync(m => m.ID == id);
            if (dT_User == null)
            {
                return NotFound();
            }

            return View(dT_User);
        }

        // POST: User/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var dT_User = await _context.DT_User.SingleOrDefaultAsync(m => m.ID == id);
            _context.DT_User.Remove(dT_User);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DT_UserExists(int id)
        {
            return _context.DT_User.Any(e => e.ID == id);
        }
    }
}
