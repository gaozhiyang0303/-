﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.DataTable
{
    public class DT_Company
    {
        public Guid Id { get; set; }
        public int Version { get; set; }
        public bool Deflag { get; set; }
        public DateTime? OptDate { get; set; }
        public string OptDateUser { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string TelPhone { get; set; }
        public DateTime? CreatTime { get; set; }
    }
}
